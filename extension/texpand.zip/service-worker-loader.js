import './assets/index.ts.24eddcd8.js';
