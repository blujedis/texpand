(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.081f630a.js")
    );
  })().catch(console.error);

})();
