(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.a4dfcc48.js")
    );
  })().catch(console.error);

})();
