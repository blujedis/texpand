(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.ts.6aed135e.js")
    );
  })().catch(console.error);

})();
